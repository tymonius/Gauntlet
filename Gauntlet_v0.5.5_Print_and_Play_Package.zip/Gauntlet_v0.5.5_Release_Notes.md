# Gauntlet v0.5.5 - Human Playtest Errata

**Status:** Pre-release physical playtest edition  
**Release date:** June 21, 2026

v0.5.5 is a focused errata patch based on the first human playtest of v0.5.4. It updates four card/Territory interactions without adding a new global pacing rule.

## Errata incorporated

### Conscription

**Battle** is reworked to function within the current battle timing:

> Draw one additional battle card. You may play one additional card from your battle draw in this battle.

### Watchtower

Watchtower now clarifies that it only reveals cards committed from hand during the normal battle commitment step:

> When the defender controls this Territory, any card the attacker commits from hand during the battle commitment step is placed face up instead of face down. Cards played from the battle draw are not hand commitments.

This clarifies the interaction with Conscription and similar effects.

### Fortifications

**Battle** is reworked into an immediate defensive effect:

> If you are the defender, gain +1 to your battle total. If you lose this battle, you may retreat one additional space.

### Embargo

**Battle** now returns a canceled card to the appropriate source/destination instead of always returning it to hand:

> Choose one opposing Battle card. That card has no effect. If it was committed from hand, return it to its owner's hand. If it was played from a battle draw, place it in its owner's discard pile.

## Pacing note

No Foothold, capture-tempo, or anti-stalemate rule is added in v0.5.5. The first human playtest indicated that the game was fun but too long and that progress was overturned too easily. Those issues are being tracked separately for a possible v0.5.6 pacing patch after additional design comparison.

## Preserved from v0.5.4

- Last Stand remains active: Heartland defenders have Homeland Advantage and gain +1 to their battle total.
- Cards committed from hand during battle go to the Graveyard.
- Cards played from the battle draw normally go to the discard pile.
- Attrition retains its locked v0.5.3 text.
- Heartland remains the endpoint and victory space terminology.
